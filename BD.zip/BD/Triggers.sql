DELIMITER //

CREATE TRIGGER trigger_check_capacite
BEFORE INSERT ON Affectation
FOR EACH ROW
BEGIN
    DECLARE nb_inscrits INT;
    DECLARE cap_max INT;
    DECLARE msg VARCHAR(255);

    SELECT capacite_max_groupe INTO cap_max 
    FROM Groupe WHERE id_groupe = NEW.id_groupe;

    SELECT COUNT(*) INTO nb_inscrits 
    FROM Affectation 
    WHERE id_groupe = NEW.id_groupe AND affectation_courante = TRUE;

    IF nb_inscrits >= cap_max THEN
        SET msg = CONCAT('Erreur : Le groupe ', NEW.id_groupe, ' est complet.');
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = msg;
    END IF;
END //

CREATE TRIGGER trigger_check_note
BEFORE INSERT ON Note
FOR EACH ROW
BEGIN
    DECLARE msg VARCHAR(255);
    IF NEW.valeur_note < 0 OR NEW.valeur_note > 20 THEN
        SET msg = CONCAT('Erreur : Note invalide (', NEW.valeur_note, '). Doit être entre 0 et 20.');
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = msg;
    END IF;
END //

CREATE TRIGGER trigger_check_note_update
BEFORE UPDATE ON Note
FOR EACH ROW
BEGIN
    DECLARE msg VARCHAR(255);
    IF NEW.valeur_note < 0 OR NEW.valeur_note > 20 THEN
        SET msg = CONCAT('Erreur : Note invalide (', NEW.valeur_note, '). Doit être entre 0 et 20.');
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = msg;
    END IF;
END //

CREATE TRIGGER trigger_check_unique_sondage
BEFORE INSERT ON ReponseSondage
FOR EACH ROW
BEGIN
    DECLARE deja_repondu INT;
    DECLARE msg VARCHAR(255);

    SELECT COUNT(*) INTO deja_repondu
    FROM ReponseSondage
    WHERE id_etudiant = NEW.id_etudiant AND id_sondage = NEW.id_sondage;

    IF deja_repondu > 0 THEN
        SET msg = CONCAT('Erreur : L étudiant ', NEW.id_etudiant, ' a déjà répondu au sondage ', NEW.id_sondage);
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = msg;
    END IF;
END //

CREATE TRIGGER trigger_gestion_historique_par_type
BEFORE INSERT ON Affectation
FOR EACH ROW
BEGIN
    DECLARE nouveau_type VARCHAR(64);

    SELECT type_groupe INTO nouveau_type 
    FROM Groupe 
    WHERE id_groupe = NEW.id_groupe;

    UPDATE Affectation a
    INNER JOIN Groupe g ON a.id_groupe = g.id_groupe
    SET a.affectation_courante = FALSE
    WHERE a.id_etudiant = NEW.id_etudiant 
    AND a.affectation_courante = TRUE
    AND g.type_groupe = nouveau_type;
END //